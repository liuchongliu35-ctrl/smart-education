import {http} from '@/utils/axios'
//根据教师ID获取教案设计历史记录列表
export function getAllDesignList(){
    return http({
      url: `/teachDesign/list/12`,
      method: 'GET',
    })
  }
//根据教师ID获取教学设计大纲模板
export function getDesignTemplateList(tid){
    return http({
      url: `/syllabus/${tid}`,
      method: 'GET',
    })
  }
//根据教案设计ID获取教学设计内容
export function getHistoryDesignContent(designId){
    return http({
      url: `/teachDesign/byId/${designId}`,
      method: 'GET',
    })
  }
//文案优化请求
export function postWordModify(data){
    return http({
      url: `/teachDesign/prompt`,
      method: 'POST',
      data:data
    })
  }
//生成图片请求
export function postGeneratePhoto(data){
    return http({
      url: `/teachDesign/photo`,
      method: 'POST',
      data:data
    })
  }
//生成视频链接请求
export function postGenerateVideo(data){
    return http({
      url: `/teachDesign/video`,
      method: 'POST',
      data:data
    })
  }
//获取章节知识点标题
export function getSubjectList(){
    return http({
      url: `/subjectSyllabus/syllabus/12`,
      method: 'GET',
    })
  }
//AI生成大纲请求
export function postAIGenerate(data){
    return http({
      url: `/syllabus/fromAI`,
      method: 'POST',
      data:data
    })
  }
//保存大纲请求
export function postSaveSyllabus(data){
    return http({
      url: `/syllabus/save/0`,
      method: 'POST',
      data:data
    })
  }
//将模板大纲插入新建教案设计
export function postPushSyllabus(data,tdid){
    return http({
      url: `/syllabus/save/${tdid}`,
      method: 'POST',
      data:data
    })
  }
//根据大纲模板id获取大纲内容
export function getSyllabusContent(sid){
  return http({
    url: `/syllabus/byId/${sid}`,
    method: 'GET',
  })
}

//新建教学设计
export function postCreateNewDesign(data){
  return http({
    url: `/teachDesign`,
    method: 'POST',
    data:data
  })
}

//临时保存教学设计内容
export function postEditorCache(data){
  return http({
    url: `/teachDesign/cache`,
    method: 'POST',
    data:data
  })
}

//获取最近修改的备课板
export function getLastPreparation(tid){
  return http({
    url: `/teachDesign/last/12`,
    method: 'GET',
  })
}

//获取最近修改的备课板
export function deleteDesignAPI(tdId){
  return http({
    url: `/teachDesign/remove/${tdId}`,
    method: 'DELETE',
  })
}