import { get, post } from '@/api'

// 获取用户信息
export const fetchUser = (userId) => get(`/users/${userId}`)

// 登录接口
export const login = (credentials) => post('/auth/login', credentials)
