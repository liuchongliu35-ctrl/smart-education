import React, { useEffect, useState } from 'react'
import {Col, Form, Input,Row,Select, } from 'antd'
import style from '../../pages/preparationBoard/preparationBoard.module.css'
import {postCreateNewDesign} from '@/apis/preparation'



const ModalComponent = ({onSubmit,topOption,allData}) =>{
    const [selectedTopTitle, setSelectedTopTitle] = useState('')
    const [secondaryTitleItem, setSecondaryTitleItem] = useState([])

  useEffect(() => {
    if (selectedTopTitle) {
     
      const filteredItems = allData.filter(
        item => item.topTitle === selectedTopTitle
      )
      const titles = filteredItems?.map(item => item.secondaryTitle)
      setSecondaryTitleItem(titles)
    } 
  }, [selectedTopTitle])

    const [form] = Form.useForm()
    const handleSubmit = (values) => {
        const prop = {
          ...values,
          authorId:12
        }
        if (onSubmit) {
        onSubmit(prop)
        }
         }


    return(
        <Form
  onFinish={handleSubmit}
  layout="vertical"
  labelCol={{ flex: '30px' }}
  labelAlign="left"
  colon={false}
  style={{ width: 240,marginTop:50}}
  form={form}

>
  {/* 一级标题 */}
  <Form.Item label="章节" name="designTitle" rules={[{ required: true, message: '章节未选择！' }]}>
    <Select
      placeholder="选择章节"
      style={{ height: 28 }}
      onChange={(value) => {
        setSelectedTopTitle(value);
        form.setFieldsValue({ secondary_title: undefined })
      }}>
        {topOption.map(item => (
      <Option 
        key={item}       
        value={item}     
      />
    ))}
    </Select>
  </Form.Item>

  {/* 二级标题 */}
  <Form.Item label="知识点" name="secondaryTitle" rules={[{ required: true, message: '知识点未选择！' }]}>
    <Select
      placeholder={selectedTopTitle ? "请选择知识点" : "请先选择章节"}
      style={{ height: 28 }}
      disabled={!selectedTopTitle}
    >
      {secondaryTitleItem.map(item => (
      <Option 
        key={item}       
        value={item}     
      />
    ))}
    </Select>
  </Form.Item>

  <Row gutter={8}>
    <Col span={10}>
      <Form.Item
        name="classTime"
        label="	课时数"
        rules={[{ required: true, message: '题型未选择！' }]}
      >
        <Input
             style={{ 
               height: 28,
               padding: '2px 8px',
               fontSize: 13
             }}
           />
      </Form.Item>
    </Col>
    <Col span={4}></Col>
    <Col span={10}>
      <Form.Item name="subject" label="学科" rules={[{ required: true, message: '难度未选择！' }]}>
        <Input
             style={{ 
               height: 28,
               padding: '2px 8px',
               fontSize: 13
             }}
           />
      </Form.Item>
    </Col>
  </Row>
  <Form.Item label="授课对象" name="target" rules={[{ required: true, message: '名称未填写！' }]}>
            <Input style={{ height: 28,padding: '2px 8px',fontSize: 13}}/> 
</Form.Item>
  <Form.Item label="教学设计名称" name="designName" rules={[{ required: true, message: '名称未填写！' }]}>
    <Input 
      placeholder="请输入教学设计名称"
    />  
</Form.Item>

  <Form.Item >
  <div style={{textAlign:'center'}}>
  <button 
      htmlType="submit"
      className={style.shengchengBtn}
    >
      下一步
    </button>
    </div>
  </Form.Item>
  

</Form>
    )
}
  export default ModalComponent