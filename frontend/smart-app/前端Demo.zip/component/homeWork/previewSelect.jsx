import React, { useEffect, useState } from 'react'
import { Button, Checkbox, Col, ConfigProvider,  Form, Input, Row, Select } from 'antd'
import style from '@/pages/homeWork/homeWork.module.css'


const { TextArea } = Input
const workTypeItem = ['单选题','多选题','填空题','简答题']


const PreviewSelectForm = ({ onSubmit,topOption,allData }) => {
  const [selectedTopTitle, setSelectedTopTitle] = useState('')
  const [secondaryTitleItem, setSecondaryTitleItem] = useState([])
  

  useEffect(() => {
  if (selectedTopTitle) {
   
    const filteredItems = allData.filter(
      item => item.topTitle === selectedTopTitle
    )
    const titles = filteredItems.map(item => item.secondaryTitle)
    setSecondaryTitleItem(titles)
  } 
}, [selectedTopTitle])

  const [form] = Form.useForm()

    const handleSubmit = (values) => {
        const prop = {
          ...values,
          problemType: values.problemType?.join(',') || '',
          questionsGrade: parseInt(values.questionsGrade, 10) || 0,
          questionsNum: parseInt(values.questionsNum, 10) || 0,
          authorId:12
        }
        if (onSubmit) {
        onSubmit(prop)
        console.log(prop)
        }
         }


   return (
    

    <ConfigProvider>
<Form
  onFinish={handleSubmit}
  layout="vertical"
  labelCol={{ flex: '30px' }}
  labelAlign="left"
  wrapperCol={{ flex: 0.5 }}
  colon={false}
  style={{ width: 320, }}
  form={form}
>
  {/* 一级标题 */}
  <Form.Item label="章节" name="ptitle" rules={[{ required: true, message: '章节未选择！' }]}>
    <Select
      placeholder="选择章节"
      style={{ height: 28 }}
      onChange={(value) => {
        setSelectedTopTitle(value);
        form.setFieldsValue({ secondary_title: undefined }) // 清除已选二级标题
      }}>
        {topOption.map(item => (
      <Option 
        key={item}       
        value={item}     
      />
    ))}
    </Select>
  </Form.Item>

  {/* 二级标题 */}
  <Form.Item label="知识点" name="secondaryTitle" rules={[{ required: true, message: '知识点未选择！' }]}>
    <Select
      placeholder={selectedTopTitle ? "请选择知识点" : "请先选择章节"}
      style={{ height: 28 }}
      disabled={!selectedTopTitle}
    >
      {secondaryTitleItem.map(item => (
      <Option 
        key={item}       
        value={item}     
      />
    ))}
    </Select>
  </Form.Item>


  <Form.Item
        name="problemType"
        label="类型"
        rules={[{ required: true, message: '题型未选择！' }]}
      >
      <Checkbox.Group options={workTypeItem} style={{marginLeft:0}} />
      </Form.Item>


  <Row gutter={8}>
    <Col span={12}>
      <Form.Item label="题目数量" name="questionsNum" rules={[{ required: true, message: '题目数量未确定！' }]}>
        <Input
          type="number"
          style={{ 
            height: 28,
            padding: '2px 8px',
            fontSize: 13
          }}
        />
      </Form.Item>
    </Col>
    <Col span={2}></Col>
    <Col span={10}>
      <Form.Item label="作业总分" name="questionsGrade" rules={[{ required: true, message: '作业总分未确定！' }]}>
        <Input
          type="number"
          style={{ 
            height: 28,
            padding: '2px 8px',
            fontSize: 13
          }}
        />
      </Form.Item>
    </Col>
  </Row>
  <Form.Item label="作业名称" name="previewName" rules={[{ required: true, message: '请输入作业名称！' }]}>
    <Input />
  </Form.Item>

  <Form.Item label="作业说明" name="pexplanation">
    <TextArea />
  </Form.Item>

  <Row tguter={8}>
      <Col span={8} offset={9}>
      <Button 
      type="primary" 
      htmlType="submit"
      style={{ height: 30 }}
      className={style.functionBtn} 
    >
      点击创建
    </Button>
      </Col>
    </Row>
  
  
</Form>

</ConfigProvider>
   
  )}
  export default PreviewSelectForm