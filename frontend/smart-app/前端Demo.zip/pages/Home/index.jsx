import React, { useEffect, useState } from 'react'
import {Layout,ConfigProvider, Avatar,Skeleton,Menu, Badge} from 'antd'
import style from './home.module.css'
import DeepSeek from '@/assets/svg/deepSeek.svg'
import { Input } from 'antd'
import Icon, {SearchOutlined,HomeOutlined,FormOutlined,TeamOutlined,ShopOutlined,CalendarOutlined} from '@ant-design/icons';
import { Outlet, useLocation, useNavigate } from 'react-router-dom'
import TeacherIcon from '../../assets/svg/关怀启迪老师.svg'

const items = [
  {
    key: '1',
    icon:<HomeOutlined />,
   },
  {
    key: '2',
    icon: <FormOutlined />,
  },{
    key: '3',
    icon:<CalendarOutlined />
  },{
    key: '4',
    icon: <TeamOutlined />,
  }

]
const {  Sider, Content } = Layout

const contentStyle = {
  minWidth:700,
  textAlign: 'center',
  minHeight: '100vh',
  lineHeight: '120px',
  color: '#fff',
  backgroundColor: '#F2F5FF',
  position:'reletive',
  marginLeft:80
  }

const siderStyle = {
  height:'100vh',
  position:'fixed',
  textAlign: 'center',
  background: '#fff',
  boxShadow:'0px 0px 2px #0000002f'
}

const layoutStyle = {
  borderRadius: 8,
  overflow: 'hidden',
  minWidth:1000,
  backgroundColor:'#fff '
}



const HomePage = () => {
  // 配置主题参数
  const ThemeConfig = {
    
    components: {
      Input: {
        activeBg:'#fff',
        activeBorderColor:'#435fff',    // 聚焦时边框
        hoverBorderColor: '#435fff',     // 悬停时边框
        paddingBlock: 10,                // 纵向间距
        paddingInline: 0,               // 横向间距
        activeShadow: '0 0 0 2px #435fff26', // 聚焦阴影
      },
      Menu: {
        iconSize:26,
        iconMarginInlineEnd:0,
        itemHeight:60,
        itemMarginInline:0,
        activeBarWidth:5,
        activeBarColor:'#3b3c50',
        itemSelectedColor:'#0B2273',
        itemBorderRadius:0,
        itemSelectedBg:'#a4abd644',
        itemBg:'#F8FAF9'
      },
    }
  }


  /*————Router控制区域—————*/
  const navigate = useNavigate()
  const location = useLocation()
  
  const currentPaths = location.pathname
  const [currentPath,setCurrentPath] = useState('1')

  function judgeRoute(e){
    switch (e) {
      case '/home':
        setCurrentPath('1')
        break;
      case '/home/preparation':
        setCurrentPath('2')
        break;
      case '/home/homeworkentry':
        setCurrentPath('3')
        break;
      case '/home/classentry':
        setCurrentPath('4')
        break;
      case '/home/preparationhistory':
        setCurrentPath('2')
        break;
      // case '/home':
      //   setCurrentPath('1')
      //   break;
      default:
        break;
    }
  }

  useEffect(() => {
   judgeRoute(currentPaths)
  }, [currentPaths]) 

  const menuOnClick = (e) => {
    // navigate(`${e.key}`)
    switch (e.key) {
      case '1':
        navigate('/home')
        setCurrentPath('1')
        break;
      case '2':
        navigate('/home/preparation')
        setCurrentPath('2')
        break;
      case '3':
        navigate('/home/homeworkentry')
        setCurrentPath('3')
        break;
      case '4':
        navigate('/home/classentry')
        setCurrentPath('4')
        break;
      default:
        break;
    }
  }

  /*———分行—————*/



  
  
  return(
    <ConfigProvider theme={ThemeConfig}
    
      >
    <Layout style={layoutStyle}>
      <Sider width={80} style={siderStyle} className={style.Sider}>
        <div style={{width:'100%',height:72,paddingInline:10}} className={style.generation}>
          <span style={{fontFamily:'youshe',color:'#435fff',fontSize:24,lineHeight:1}}>小智备课</span>
        </div>
 
        <Menu
      onClick={menuOnClick}
      style={{
        width: '100%',
        marginTop:'180%',
      }}
      // defaultSelectedKeys={['1']}
      mode="inline"
      items={items}
      selectedKeys={[`${currentPath}`]}
    />
      <div style={{width:'100%',paddingInline:10,position:'absolute',bottom:100}} className={style.avatarStyle}>
      <Badge 
      style={{ backgroundColor: '#52c41a' }}
      dot={true}>
         <Avatar src={TeacherIcon} size={56} />
      </Badge>
      <div style={{fontFamily:'siyuan',fontSize:13,marginTop:10,color:'#414141'}}>张晓丽</div>
      </div>
      </Sider>
      <Layout style={{backgroundColor:'#fff'}}>


        <Content style={contentStyle} className={style.content}>
        <Outlet />
        </Content>
        {/* <Footer style={footerStyle}>Footer</Footer> */}
      </Layout>
    </Layout>
    </ConfigProvider>
)}
export default HomePage