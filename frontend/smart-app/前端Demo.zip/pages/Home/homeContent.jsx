import { useNavigate } from 'react-router-dom'
import style from './home.module.css'
import Icon,{PlusCircleFilled,ReconciliationFilled,UserOutlined} from '@ant-design/icons'
import { Avatar, Divider, Progress } from 'antd'
import GirlSvg from "@/assets/svg/飞奔女备份.svg"
import Schedul from '@/assets/png/schedul.png'
import DateComponent from '@/component/Home/dateComponent'
import ProgressIcon from '../../assets/svg/人机交互.svg'
import HomeworkIcon from '../../assets/svg/习题图标.svg'
import ClassIcon from '../../assets/svg/合作客户.svg'
import PreparationIcon from '../../assets/svg/备课板图标.svg'
import { getLastPreparation } from '../../apis/preparation'
import { useEffect, useState } from 'react'
import NoneData from '../../assets/svg/暂无内容.svg'


const HomeContent = () => {

    const navigate = useNavigate()
    const [lastDesignName,setLastDesignName] = useState('')
    const [lastModify,setLastModify] = useState('')
    const [dId,setDId] = useState()
    //数据请求
    const getData = async()=>{
      let {data} = await getLastPreparation()
      setLastDesignName(data[0].designName)
      setLastModify(data[0].lastModify)
      setDId(data[0].tdId)
    }
     useEffect(() => {
        getData()
      }, [])

    function handleNavigate(e){
        navigate(e)
    }

    return (
        <div style={{width:'100%',padding:20,height:'100%'}}>
        <div className={style.generation} style={{flexDirection:'column'}}>
            <div className={style.titleTextBox}>
                <div style={{width:'max-content',height:'max-content'}}>Advancing creativity</div>
                <div style={{width:'max-content',height:'max-content'}}>with artificial intelligence</div>
            </div>
            <div style={{lineHeight:1.5,marginBottom:20,fontFamily:'siyuan',fontSize:25,color:'#000',width:'84%',textAlign:'left'}}>快速开始</div>
            <div className={style.entryBox}>
                
                <div className={style.entryStyle}>
                    <div style={{width:'100%',display:'flex',alignItems:'center'}}>
                        <span style={{fontSize:24,fontFamily:'none',fontWeight:600}}>备课板</span>
                        <Divider type='vertical' /> 
                        <span style={{color:'#727272'}}>preparation board</span>
                    </div>
                    <div style={{fontSize:14,width:'100%',textAlign:'left',marginTop:20,color:'#0B2273'}}>AI智能备课，释放教师创造力</div>
                    <div className={style.preEntryBtn} style={{marginTop:15,fontSize:12,paddingInline:10}} onClick={()=>handleNavigate('/home/preparation')}>新建</div>
                    <div className={style.preEntryBtn} style={{marginTop:10,fontSize:12,paddingInline:10}} onClick={()=>handleNavigate('/home/preparationhistory')}>历史记录</div>
                    <Avatar src={PreparationIcon} size={120} className={style.entryCardIcon}/>
                </div>
                <div className={style.entryStyle}>
                    <div style={{width:'100%',display:'flex',alignItems:'center'}}>
                        <span style={{fontSize:24,fontFamily:'none',fontWeight:600}}>习题</span>
                        <Divider type='vertical' /> 
                        <span style={{color:'#727272'}}>exercise</span>
                    </div>
                    <div style={{fontSize:14,width:'100%',textAlign:'left',marginTop:20,color:'#0B2273'}}>精准题目生成，分层教学无忧</div>
                    <div className={style.preEntryBtn} style={{marginTop:25}} onClick={()=>handleNavigate('/home/homeworkentry')}>创建习题</div>
                    <Avatar src={HomeworkIcon} size={120} className={style.entryCardIcon}/>
                </div>
                <div className={style.entryStyle} >
                <div style={{width:'100%',display:'flex',alignItems:'center'}}>
                        <span style={{fontSize:24,fontFamily:'none',fontWeight:600}}>班级</span>
                        <Divider type='vertical' /> 
                        <span style={{color:'#727272'}}>class</span>
                    </div>
                    <div style={{fontSize:14,width:'100%',textAlign:'left',marginTop:20,color:'#0B2273'}}>多维学情分析，教学决策有据可依</div>
                    <div className={style.preEntryBtn} style={{marginTop:25}} onClick={()=>handleNavigate('/home/classentry')}>进入班级</div>
                    <Avatar src={ClassIcon} size={120} className={style.entryCardIcon}/>
                </div>
            </div>

            <div className={style.cardBox}>
                <div style={{width:'100%',height:'max-content',display:'flex',marginBottom:30,justifyContent:'space-between'}}>
                <div className={style.progressCard}>
                    <div style={{width:'100%',padding:20,background:"linear-gradient( 145deg, #9294E9 18%, #6581ED 100% )"}}>
                        <div style={{width:'100%',fontSize:18,fontWeight:600,textAlign:'left',marginBottom:30}}>备课板</div>
                        <div style={{width:'100%',fontSize:24,fontFamily:'siyuan',marginBottom:20}}>{lastDesignName}</div>
                        <div>上次修改：{lastModify}</div>
                        <div><button className={style.progressCardBtn} onClick={()=>navigate(`/texteditor/${dId}`)}>继续编辑</button></div>
                        <Avatar shape='square' src={ProgressIcon}  size={180} />
                    </div>
                </div>

                <div className={style.dateCard} style={{width:'44%'}}>
                    <div style={{width:'100%',padding:20,display:'flex',flexDirection:'column'}}>
                    <div style={{width:'100%',height:20,fontSize:18,fontWeight:600,textAlign:'left',marginBottom:10}}>课程表</div>
                    <div style={{height:'100%'}}>
                    <Avatar src={NoneData}  size={256}/>
                    <div style={{fontFamily:'youshe',fontSize:24}}>暂无数据</div>
                    </div>                                       
                    </div>
                </div>
                
                <div className={style.previewCard}>
                <div style={{padding:20}}>
                        <div style={{width:'100%',fontSize:16,fontWeight:600,textAlign:'left',marginBottom:10}}>今日预习情况</div>
                        <div style={{width:'100%',height:80,padding:10,borderBottom:'2px solid #eaeaea',display:'flex'}}>
                            <div style={{marginRight:20,width:80}}>
                            <Avatar shape="square" size={40} icon={<UserOutlined />} style={{background:'#f56a00'}} />
                            <div style={{fontFamily:'siyuan',marginTop:5}}>高二3班</div>
                            </div>
                            <div style={{flex:1}}>
                            <div style={{marginBottom:15,fontSize:12,color:"#505050",display:'flex',justifyContent:'space-between'}}><div>已提交：8</div> <div>未提交：12</div></div>
                            <Progress percent={30} showInfo={false} />
                            </div>
                        </div>

                        <div style={{width:'100%',height:80,padding:10,borderBottom:'2px solid #eaeaea',display:'flex'}}>
                            <div style={{marginRight:20,width:80}}>
                            <Avatar shape="square" size={40} icon={<UserOutlined />} style={{background:'#422dff'}} />
                            <div style={{fontFamily:'siyuan',marginTop:5}}>高二5班</div>
                            </div>
                            <div style={{flex:1}}>
                            <div style={{marginBottom:15,fontSize:12,color:"#505050",display:'flex',justifyContent:'space-between'}}><div>已提交：8</div> <div>未提交：7</div></div>
                            <Progress percent={60} showInfo={false}  strokeColor={{from: '#108ee9',to: '#87d068'}}/>
                            </div>
                        </div>
                        <div style={{width:'80%',aspectRatio:'7/3',margin:'auto',marginTop:'10%',borderRadius:10,background:'#5E4ADD',display:'flex',alignItems:'center'}}>
                            <img src={GirlSvg} style={{width:'30%',marginLeft:'10%'}}/>
                            <div style={{fontSize:16,fontFamily:'siyuan',color:'#fff',marginLeft:'5%'}}>今日继续加油！</div>
                        </div>
                    </div>
                </div>
                </div>

                {/* <div style={{width:'100%',height:'max-content',display:'flex',justifyContent:'space-between'}}>
                <div className={style.resourceCard}></div>
                <div className={style.homeWorkCard}>
                    
                </div>
                </div> */}
            </div>
        </div>
        
        </div>
    )
  }
  export default HomeContent
