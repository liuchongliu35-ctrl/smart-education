import React, { useEffect, useState } from 'react'
import style from './entryPage.module.css'
import BackgroundImg from '../../assets/svg/小智备课Background.svg'
import {RightIcon} from '../../assets/icons'
import {ArrowRightOutlined} from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import {Input, Checkbox,Form, Row, Col, Radio} from 'antd'


const Introduce = () => (
  <div style={{width:'100%',marginTop:150}}>
    <div style={{fontSize:40,fontFamily:'youshe',color:'#435fff',lineHeight:1.5}}>小智备课</div>
    <div style={{fontSize:26,fontFamily:'siyuan',color:'#000000',lineHeight:1.5}}>AI智能教学助手，让备课更高效</div>
    <div style={{fontSize:16,color:'#6e6e6e',lineHeight:1.2,marginTop:10}}>AI making lesson preparation more efficient</div>
    <div style={{marginTop:40,fontSize:20,fontFamily:'siyuan',color:'#303030'}}>
      <span style={{marginRight:10}}><RightIcon /></span>AI智能备课，释放教师创造力
    </div>
    <div style={{marginTop:30,fontSize:20,fontFamily:'siyuan',color:'#303030'}}>
      <span style={{marginRight:10}}><RightIcon /></span>精准题目生成，分层教学无忧
    </div>
    <div style={{marginTop:30,fontSize:20,fontFamily:'siyuan',color:'#303030'}}>
      <span style={{marginRight:10}}><RightIcon /></span>多维学情分析，教学决策有据可依
    </div>
    <button className={style.loginButton}><ArrowRightOutlined  style={{marginRight:10}}/>立即登录</button>
  </div>
)

const Login = ({handleClick}) =>(
  <div style={{width:'100%',height:400,background:'#fff',display:'flex',alignItems:'center',flexDirection:'column',justifyContent:'center',marginTop:160,boxShadow:'0px 0px 8px #6e6e6e45',borderRadius:10}}>
  <div style={{width:'60%'}}>
  <div style={{fontSize:34,marginBottom:20,fontFamily:'youshe',color:'#435fff',lineHeight:1.5,textAlign:'center'}}>小智备课</div>
  <div>用户名</div>
  <Input style={{background:'#F2F5FF',fontSize:12,height:35}} placeholder='请输入用户名'/>
  <div style={{marginTop:20}}>密码</div>
  <Input.Password style={{background:'#F2F5FF',fontSize:12,height:35}} placeholder='请输入密码' />
  <div style={{marginTop:10,display:'flex'}}>
  <Checkbox style={{fontFamily:'none',fontSize:13,color:'#21353c'}}>记住密码</Checkbox>
  <div style={{flex:1}}></div>
  <div style={{fontFamily:'none',fontSize:13,color:'#21353c',textDecoration:'underline',cursor:'pointer'}} >立即注册</div>
  </div>
  <div style={{width:'max-content',margin:'auto',marginTop:40}}><button className={style.loginBtn} onClick={()=>handleClick()} style={{paddingInline:80}}>登录</button></div>
  </div>
</div>
)

const Register = ({onChange}) =>(
  <div style={{width:'100%',height:'max-content',paddingBlock:30,background:'#fff',display:'flex',alignItems:'center',flexDirection:'column',justifyContent:'center',marginTop:100,boxShadow:'0px 0px 8px #6e6e6e45',borderRadius:10}}>
  <div style={{width:'60%'}}>
  <div style={{fontSize:30,marginBottom:20,fontFamily:'siyuan',lineHeight:1.5,textAlign:'center'}}>教师注册</div>
  <Form
    // onFinish={handleSubmit}
    layout="vertical"
    labelCol={{ flex: '30px' }}
    labelAlign="left"
    wrapperCol={{ flex: 0.5 }}
    colon={false}>
    <Form.Item label="账号" name="account" rules={[{ required: true, message: '请输入作业名称！' }]}>
        <Input />
      </Form.Item>

      <Form.Item label="密码" name="" rules={[{ required: true, message: '请输入作业名称！' }]}>
        <Input />
      </Form.Item>
      <Form.Item label="确认密码" name="" rules={[{ required: true, message: '请输入作业名称！' }]}>
        <Input />
      </Form.Item>
      <Row gutter={8}>
<Col span={12}>
<Form.Item label="电话号码" name="questionsNum" rules={[{ required: true, message: '题目数量未确定！' }]}>
<Input
  type="number"
  style={{ 
    height: 28,
    padding: '2px 8px',
    fontSize: 13
  }}
/>
</Form.Item>
</Col>
<Col span={2}></Col>
<Col span={10}>
<Form.Item label="性别" name="questionsGrade" rules={[{ required: true, message: '作业总分未确定！' }]}>
<Radio.Group onChange={onChange} >
  <Radio value={'男'}>男</Radio>
  <Radio value={'女'}>女</Radio>
</Radio.Group>
</Form.Item>
</Col>
      </Row>
      <Form.Item label="年级" name="previewName" rules={[{ required: true, message: '请输入作业名称！' }]}>
        <Input />
      </Form.Item>

      <Form.Item label="科目" name="pexplanation" rules={[{ required: true, message: '请输入作业名称！' }]}>
        <Input />
      </Form.Item>
      <Form.Item>
          <div style={{width:'max-content',margin:'auto',marginTop:40}}><button className={style.loginBtn} onClick={()=>handleClick()} style={{paddingInline:80}}>注册</button></div>
          </Form.Item>

</Form>
  </div>
    </div>
)

const EntryPage = () => {

  const navigate = useNavigate()

  const handleClick = () =>{
    sessionStorage.setItem('currentList', '预习任务')
    navigate('/home')
  }

  const onChange = (e) => {
    console.log('radio checked', e.target.value)
    setValue(e.target.value)
  }
  const [currentState,setCureentState] = useState(1)

  function render(e){
    switch (e) {
      case 1:
        return <Introduce />
      case 2:
        return <Login handleClick={handleClick} />
      case 3:
        return <Register onChange={onChange} />
    
      default:
        break;
    }
  }



  return (
    <>
    <div style={{width:'100%',background:'#F2F5FF',minWidth:1400}}>
      <div style={{width:'90%',margin:'auto',display:'flex',position:'relative'}}>
        <div className={style.header}>
          <span style={{fontSize:28,fontFamily:'youshe',color:'#435fff'}}>小智备课</span>
          <span style={{cursor:'pointer',fontSize:16,fontFamily:'siyuan',marginLeft:30}}>首页</span>
          <span style={{cursor:'pointer',fontSize:16,fontFamily:'siyuan',marginLeft:30,color:'#727272'}}>合作</span>
          <span style={{cursor:'pointer',fontSize:16,fontFamily:'siyuan',marginLeft:30,color:'#727272'}}>了解更多</span>
          <span style={{flex:1}}></span>
          <button className={style.registerBtn} onClick={()=>setCureentState(3)}>教师注册</button>
          <button className={style.loginBtn} onClick={()=>setCureentState(2)}>登录</button>
        </div>
          <div style={{flex:1,display:'flex',paddingInline:30}}>
            {render(currentState)}

          </div> 
        <div style={{width:'62%'}}>
          <img src={BackgroundImg} />
        </div>
      </div>
    </div>
    </>
  )
}

export default EntryPage  