import { createBrowserRouter } from "react-router-dom"
import HomePage from "@/pages/Home/index"
import TestPage from "@/pages/Test/Test"
import EntryPage from "@/pages/Entry"
import PreparationBoard from "@/pages/preparationBoard"
import HomeWorkPage from "@/pages/homeWork"
import TextEditorPage from "@/pages/TextEditor"
import HomeContent from "@/pages/Home/homeContent"
import PreparationBoardHistory from '@/pages/preparationBoard/history'
import HomeworkEntry from "@/pages/homeWork/homeWorkEntry"
import ClassEntry from "@/pages/Class/classEntry"
import ClassPage from "@/pages/Class"
import BoardTemplate from "@/pages/preparationBoard/template"
import AIpreparation from "@/pages/preparationBoard/AIpreparation"
import ClassMemberPage from "@/pages/Class/classMember"
import ClassContent from "@/pages/Class/classContent"
import PreviewList from "@/pages/Class/previewList"
import HomeWorkList from "@/pages/Class/homeWorkList"
import ExamList from "@/pages/Class/examList"
import StudentAnswerDetail from "@/pages/Class/studentAnswerDetail"
import StudentTrackPage from "@/pages/homeWork/studenTrack"
import StudentHomeworkTrackPage from "../pages/homeWork/studentHomeworkTrack"
import PreviewWorkPage from "../pages/homeWork/previewWork"
import StudentHomeworkDetail from "../pages/Class/studentHomework"
import CustomTextEditor from "../component/Editor/CustomTextEditor"

// import CustomTextEditor from "@/component/Editor/CustomTextEditor"
import NonePage from "@/pages/Home/404"
    const router = createBrowserRouter([
      {
        path: "/",
        element: <EntryPage />,
      },
      {
        path: "/404",
        element: <NonePage />,
      },
      {
        path: "/home",
        element: <HomePage />,
        children:[
          {index:true,element:<HomeContent />},
          {path: "preparation", element: <PreparationBoard />},
          {path:"preparationhistory",element:<PreparationBoardHistory />},
          {path:"homeworkentry",element:<HomeworkEntry />},
          {path:"classentry",element:<ClassEntry />},
          {path:"template",element:<BoardTemplate />},
          {path:"aipreparation",element:<AIpreparation />},
          
        ]
      },
      {
        path: "/texteditor/:design_id",
        element: <TextEditorPage />,
      }
      ,{
        path: "/customeditor",
        element: <CustomTextEditor />,
      }
      ,{
        path: "/homework/:h_id",
        element: <HomeWorkPage />,
      },{
        path: "/preview/:p_id",
        element: <PreviewWorkPage />,
      },
      {
        path: "/test",
        element: <TestPage />,
      },{
        path:"/previewdetail/:u_id/:w_id",
        element:<StudentTrackPage />
      },{
        path:"/workdetail/:u_id/:w_id",
        element:<StudentHomeworkTrackPage />
      },{
        path:"/class/:c_id",
             element:<ClassPage />,
             children:[
             {index:true,element:<ClassContent />},
             {path:"member",element:<ClassMemberPage />},
             {path:"preview",element:<PreviewList />},
             {path:"exercise",element:<HomeWorkList />},
             {path:"exam",element:<ExamList />},
             {path:"detail/:p_id",element:<StudentAnswerDetail />},
             {path:"homeworkdetail/:h_id",element:<StudentHomeworkDetail />}
           ]
      }
    ])

export default router